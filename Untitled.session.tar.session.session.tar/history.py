exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
compute_names
self._downloaded_data['Code']
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
c
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
n
n
self._downloaded_data
self._downloaded_data['Code']
compute_names(self._downloaded_data['Code'])
compute_names(self._downloaded_data['Code'].tolist())
self._downloaded_data['Code']
compute_names
compute_names(self._downloaded_data['Code'].iloc[0])
self._downloaded_data['Code'][0]
compute_names(self._downloaded_data['Code'])
s
n
s
n
col_name
n
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
n
code
codes
col_name
n
col_name
n
s
n
c
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
col_name
compute_naems
compute_names
col_name
codes
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
n
c
n
qd_code
codes.loc[codes['Code']==qd_code]['Name'].iloc[0]
codes['Code']
codes['Code']==qd_code
codes.loc[codes['Code']==qd_code]
qd_code
codes['Code']==qd_code
qd_code
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
name
c
name
c
name
c
name
c
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
name
c
name
c
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
n
codes.to_dict()
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
n
codes
c
codes[qd_code]
codes.loc[qd_code]
codes.index
c
codes[qd_code]
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
symbol
ind
n
ind
n
self._downloaded_data['Code']
self._downloaded_data['Code'][50:100]
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
codes[qd_code]
codes.loc[qd_code]
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
codes.loc[qd_code]
c
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
qd_code
codes.iloc[0]
codes.loc['SF0/AAC_ASSETSC_MRY']
codes.loc['SF0/AAC_ASSETSC_MRY']['Name
codes.loc['SF0/AAC_ASSETSC_MRY']['Name']
c
n
row
self._downloaded_data['Code'].iloc[row]
self._downloaded_data['Code'].loc[row]
n
ind
sp
n
res
n
res
c
self._downloaded_data['Name']
self._downloaded_data.columns
self._downloaded_data['Code']
n
sym
ind
self._downloaded_data['Code']
self._downloaded_data['Code'][0]
self._downloaded_data['Code'][10]
english_to_symbol_indicator(self._downloaded_data['Code'][10])
c
res
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
qd_code
c
DataFrame.from_dict(res)
n
path
n
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
date,sym
res.keys()[0]
list(res.keys())[0]
n
res[date, sym]
res.__len__()
res.keys()
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
n
cont
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
s
n
s
n
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
n
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
english_to_symbol_indicator
s
n
n> /Users/davidadelberg/anaconda/lib/python3.5/site-packages/pandas/core/generic.py(1315)_indexer() -> i = indexer(self, name) (Pdb) 
n
n> /Users/davidadelberg/anaconda/lib/python3.5/site-packages/pandas/core/indexing.py(1291)__getitem__() -> key = com._apply_if_callable(key, self.obj) (Pdb) 
n> /Users/davidadelberg/anaconda/lib/python3.5/site-packages/pandas/core/indexing.py(1293)__getitem__() -> if type(key) is tuple: (Pdb) 
n
english
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
n
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
n
s
n
n> /Users/davidadelberg/anaconda/lib/python3.5/site-packages/pandas/core/frame.py(1980)__getitem__() -> return self._getitem_column(key) (Pdb) 
n
n> /Users/davidadelberg/Google Drive/Documents/systematic_investment/systematic_investment/shortcuts.py(168)res() -> for col in columns: (Pdb) 
n
col_handler
s
n
name
c
qd_code
c
english_to_symbol_indicator
n
sp
english
n
symbol
c
sym
ind
n
date
n
date
sym
ind
val
ind
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
n
english
c
sym
ind
c
res
c
ind
c
ind
c
cc
res
c
date
sym
ks = res.keys()
ks[0]
ks = list(ks)
ks[0]
ks[-1]
c
DataFrame.from_dict(res)
n
c
runfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
n
s
exit
runfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
s
n
data.index
self._downloaded_data
self._downloaded_data.index
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
n
data.index
data.index.levels[0]
data.index.levels[1]
n
data.index
data.index.to_datetime()
data.index.levels[0]
data.index.levels[0].to_datetime()
data.index
data.index[0]
data.index.levels[1]
data.index.to_datetime()
data.index.levels[1].to_datetime(inplace=True)
data.index.levels[0]
x = DataFrame()
x.index.levels
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
n
idx_to_datetime
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
idx_to_datetime
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
n
r, (Pdb) 
idx_to_datetime
english_to_symbol_indicator
exit
runfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
idx_to_datetime
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
multi_idx_to_datetime
idx_to_datetime
n
MultiIndex(idx.levels[0], idx.levels[1])
from pandas import MultiIndex
MultiIndex(idx.levels[0], idx.levels[1])
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
n
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
n
data.index
data.index.levels[0]
data.index.levels[1]
n
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
idx_to_datetime
n
s
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
data.groupby(gnames)
gnames
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
data.index.names
data.index.name
data.index.names
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_investment/systematic_investment/shortcuts.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_investment/systematic_investment')
continue
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
data.index
self._downloaded_data.names
self._downloaded_data.index.names
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
s
n
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
s
n
self._downloaded_data.index
c
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
n
c
n
data.groupby(gnames).resample('AS').pad()
gnames
data[gnames]
data.index.names
data.groupby('Date')
data.groupby('Date', axis=1)
data.groupby(subset=['Date'], axis=1)
data.groupby(level=0)
data.groupby(level=0).index
data.groupby(level=0)
data.groupby(level='Date')
data.groupby(level=['Security']
data.groupby(level=['Security'])
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
n
data.groupby(level=gnames).resample('AS').pad()
data.groupby(level=gnames).index
data.groupby(level=gnames).resample('AS')
data.groupby(level=gnames).levels
data.groupby(level=gnames).resample
data.groupby(level=gnames).describe()
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
data.groupby(level=gnames).resample('AS')
data.groupby(level=gnames)
data.groupby(level=gnames, as_index=False))
data.groupby(level=gnames, as_index=False)
data.groupby(level=gnames, as_index=False).resample
data.groupby(level=gnames, as_index=False).resample('AS')
data.groupby(level=gnames, as_index=False)[0]
data.groupby(level=gnames, as_index=False).columns
data.groupby(level='Security', as_index=False)
data.groupby(level='Security', as_index=False).resample('AS')
data.groupby(level='Date', as_index=False).resample('AS')
data.groupby(level='Date').resample('AS')
data.index
data.index.levels[0]
data.index.levels[0].resample
data['Date']
data.index['Date']
data.index['Date'].loc['Date']
data.index.levels[0]
resample(data.index.levels[0])
data.groupby(level='Security')
gb = data.groupby(level='Security')
gb.indices
gb.resample('AS')
gb.indices[0]
gb.indices
gb.apply(lambda x: x.resample('AS'))
gb.groups[0]
gb.groups
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
n
english_to_symbol_indicator
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
s
n
english
c
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
n
info
s
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
s
n
dl
dl.load()
s
n
self.do_downloads()
verbose
n
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
s
n
dl
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
s
n
s
n
self.do_downloadsn
n
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
s
n
c
s
n
self._info["dbs"]
n
db_info["create_downloader"]
db_info
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
n
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
s
n
s
n
s
n
c
db_info["code_builder"]
db_info["name_builder"]
db_info["symbols"]
exiit
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
db_info["code_builder"]
db_info
def f(x): return(x)
f(None)
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
n
db_info["download_and_save"]
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
english
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
s
n
english
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
n
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
s
n
english_to_symbol_indicator
self._downloaded_data['Code'].loc[row]
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
s
n
s
c
s
c
s
n
compute_names
n
english_to_symbol_indicator
n
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
english
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
english_to_symbol_indicator
n
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
s
n
exit
runfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
n
s
n
model_class
info
s
n
s
n
s
info.analyzer.create
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
n
s
n
model_class
n
model_class
model_class(info)
info
s
n
info
s
n
info.analyzer.path
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
n
s
n
s
n
s
n
info.analyzer.path
n
info.analyzer.load
n
info.y_key
n
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
s
n
s
n
s
n
exit
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
debugfile('/Users/davidadelberg/Google Drive/Documents/systematic_analyses/test.py', wdir='/Users/davidadelberg/Google Drive/Documents/systematic_analyses')
continue
c
x = 2